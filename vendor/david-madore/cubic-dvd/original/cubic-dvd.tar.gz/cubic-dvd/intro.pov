// Camera

camera {
  location <0, 0, -24.9*(1-clock)*(1-clock)-0.1>
  look_at <0, 0, 0>
  angle 30
}

// The surface itself

// The (smooth) Clebsch cubic surface (with 27 lines).

intersection {
  cubic {
    <0.62853936105, -1.33333333333, 0, -1, 0, 0, 0, -1.88561808316, 0, 0,
     0.88888888889, 0, -1, -1.33333333333, 0, 0, 0, -1, 0, 0.9375-0.0001> sturm
  }
  cubic {
    <-0.62853936105, 1.33333333333, 0, 1, 0, 0, 0, 1.88561808316, 0, 0,
     -0.88888888889, 0, 1, 1.33333333333, 0, 0, 0, 1, 0, -0.9375-0.0001> sturm
  }
  sphere {
    <0, 0, 0>, 4
  }
  rotate <0, 90, 0>
  texture {
    pigment { red 1.0 green 1.0 blue 1.0 }
    finish { ambient .2 diffuse .4 phong .3 reflection .2 }
  }
}

// Light sources!

light_source {
  <1000, 2000, -1732>
  rgb <1,0,0>
}

light_source {
  <0, 5000, 0>
  rgb <0,1,0>
}

light_source {
  <-500, -2000, 0>
  rgb <0,0,1>
}
